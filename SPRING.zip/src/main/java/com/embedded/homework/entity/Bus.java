package com.embedded.homework.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "bus")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String busID;

    @Column
    private String route;

    @Column
    private Double temperture;

    @Column
    private Integer humidity;

    @Column
    private Integer numberOfPassengers;

    @Column
    private Instant updatedAt;


}
