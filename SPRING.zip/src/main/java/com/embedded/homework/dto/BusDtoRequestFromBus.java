package com.embedded.homework.dto;

import lombok.Data;

@Data

public class BusDtoRequestFromBus {

    private String route;
    private String busId;
    private Double temperture;
    private Integer humidity;
    private Integer numberOfPassengers;

}
