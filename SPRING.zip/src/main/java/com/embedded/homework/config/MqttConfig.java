package com.embedded.homework.config;

import com.embedded.homework.dto.BusDtoRequestFromBus;
import com.embedded.homework.service.IBusService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

@Configuration
@EnableIntegration         // ÇÖZÜM 1: Spring Integration'ı aktif ettik
@IntegrationComponentScan  // ÇÖZÜM 1: Etiketleri taramasını söyledik
public class MqttConfig {

    @Bean
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageProducer inbound(){
        MqttPahoMessageDrivenChannelAdapter adapter =
                new MqttPahoMessageDrivenChannelAdapter("tcp://localhost:1883",
                        "springBootBackendClient",
                        "otobussistemi/+/+/veri");
        
        adapter.setCompletionTimeout(5000);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setQos(1);

        // ÇÖZÜM 2: Fonksiyonu çağırmak yerine direkt borunun ismini (String) verdik
        adapter.setOutputChannelName("mqttInputChannel");
        return adapter;
    }

    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler(IBusService busService) {

        return new MessageHandler() {
            @Override
            public void handleMessage(Message<?> message) throws MessagingException {

                String topic = (String) message.getHeaders().get("mqtt_receivedTopic");
                String payload = (String) message.getPayload();

                System.out.println("Yeni veri geldi! Topic: " + topic + " | Veri: " + payload);

                try{
                    ObjectMapper objectMapper = new ObjectMapper();
                    BusDtoRequestFromBus dto = objectMapper.readValue(payload,BusDtoRequestFromBus.class);
                    busService.processAndSaveTemperature(dto);
                }catch (Exception e){
                    System.err.println("Gelen veri işlenirken hata oluştu: " + e.getMessage());
                }
            }
        };
    }
}