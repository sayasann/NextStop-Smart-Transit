package com.embedded.homework.service.impl;

import com.embedded.homework.dto.BusDtoRequestFromBus;
import com.embedded.homework.entity.Bus;
import com.embedded.homework.repository.BusRepository;
import com.embedded.homework.service.IBusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class BusServiceImpl implements IBusService {


    @Autowired
    BusRepository busRepository;


    @Override
    public void processAndSaveTemperature(BusDtoRequestFromBus dto) {

        Bus bus = new Bus();
        bus.setBusID(dto.getBusId());
        bus.setTemperture(dto.getTemperture());
        bus.setHumidity(dto.getHumidity());
        bus.setRoute(dto.getRoute());
        bus.setUpdatedAt(Instant.now());
        bus.setNumberOfPassengers(dto.getNumberOfPassengers());

        busRepository.save(bus);
        System.out.println("Sistem: " + dto.getBusId() + " numaralı otobüsün verisi veritabanına kaydedildi.");
    }
}
