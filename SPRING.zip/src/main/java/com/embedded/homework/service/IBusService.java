package com.embedded.homework.service;

import com.embedded.homework.dto.BusDtoRequestFromBus;

public interface IBusService {

    public void processAndSaveTemperature(BusDtoRequestFromBus dto);
}
